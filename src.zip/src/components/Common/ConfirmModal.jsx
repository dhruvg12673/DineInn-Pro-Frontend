import React from 'react';

const ConfirmModal = () => {
  return (
    <div>
      ConfirmModal
    </div>
  );
};

export default ConfirmModal; 