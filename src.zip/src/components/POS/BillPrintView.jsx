import React from 'react';

const BillPrintView = () => {
  return (
    <div>
      BillPrintView
    </div>
  );
};

export default BillPrintView; 