import React from 'react';

const POSContext = () => {
  return (
    <div>
      POSContext
    </div>
  );
};

export default POSContext; 