import React from 'react';

const TableContext = () => {
  return (
    <div>
      TableContext
    </div>
  );
};

export default TableContext; 