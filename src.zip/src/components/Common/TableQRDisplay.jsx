import React from 'react';

const TableQRDisplay = () => {
  return (
    <div>
      TableQRDisplay
    </div>
  );
};

export default TableQRDisplay; 